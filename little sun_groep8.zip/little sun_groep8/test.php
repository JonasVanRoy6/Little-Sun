<?php
include "db_conn.php";

// Locaties ophalen uit de database
$locations = array();
$locationsQuery = $conn->query("SELECT id, name FROM locations");



// Gebruikers toevoegen aan locatie
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $locationId = $_POST['location_id'];
    $username = $_POST['username'];

    // Voeg de gebruiker toe aan de database
    $statement = $conn->prepare("INSERT INTO location_users (location_id, username) VALUES (?, ?)");
    $statement->execute([$locationId, $username]);
    header("Location: user_per_locatie.php");
    exit();

}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Locations</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <h1>Locations</h1>
    <ul>
        <?php foreach ($locationsQuery as $location): ?>
            <li>
                <?php echo $location['name']; ?>
                <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                    <input type="hidden" name="location_id" value="<?php echo $location['id']; ?>">

                    <input type="text" name="username" placeholder="Username">
                    <button type="submit">Add User</button>
                </form>
            </li>
        <?php endforeach; ?>
    </ul>
</body>

</html>