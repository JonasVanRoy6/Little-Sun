<?php

include "db_conn.php";
include_once ("home.php");

// Stap 2: Haal de account ID op die moet worden verwijderd
$users_id = $_POST['users'];

// Stap 3: Verwijder het account uit de database
$sql = "DELETE FROM users WHERE id=$users_id";

if ($conn->query($sql) === TRUE) {
    echo "Account succesvol verwijderd";
} else {
    echo "Fout bij het verwijderen van het account: " . $conn->error;
}

$conn->close();
?>